import { Component } from '@angular/core';

@Component({
  selector: 'app-basic-importance',
  templateUrl: './basic-importance.component.html',
  styleUrls: ['./basic-importance.component.css']
})
export class BasicImportanceComponent {

 


}
