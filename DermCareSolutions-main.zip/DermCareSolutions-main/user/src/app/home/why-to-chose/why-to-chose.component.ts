import { Component } from '@angular/core';

@Component({
  selector: 'app-why-to-chose',
  templateUrl: './why-to-chose.component.html',
  styleUrls: ['./why-to-chose.component.css']
})
export class WhyToChoseComponent {

}
